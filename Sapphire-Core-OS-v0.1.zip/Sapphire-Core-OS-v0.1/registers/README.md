# Canonical Registers

This directory will contain machine-readable and human-readable registers for:

- Business Object Types
- Relationship Types
- Lifecycle Definitions
- Lifecycle States
- Workflow Definitions
- Workflow Patterns
- Decision Classes
- Authority Rules
- Authority Grants
- Approval Patterns
- Policies
- Controls
- Evidence Types
- Metrics
- Architecture Standards
