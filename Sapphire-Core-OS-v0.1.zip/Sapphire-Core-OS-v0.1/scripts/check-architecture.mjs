import fs from "node:fs";
import path from "node:path";

const requiredFiles = [
  "README.md",
  "GOVERNANCE.md",
  "CONTRIBUTING.md",
  "architecture/MASTER-ARCHITECTURE.md",
  "architecture/STATUS.md",
  "architecture-manifest.json",
];

const missing = requiredFiles.filter((file) => !fs.existsSync(path.resolve(file)));

if (missing.length > 0) {
  console.error("Missing required architecture files:");
  for (const file of missing) console.error(`- ${file}`);
  process.exit(1);
}

const manifest = JSON.parse(
  fs.readFileSync(path.resolve("architecture-manifest.json"), "utf8"),
);

if (!Array.isArray(manifest.locked_modules) || manifest.locked_modules.length === 0) {
  console.error("architecture-manifest.json must declare locked_modules.");
  process.exit(1);
}

console.log("Architecture repository checks passed.");
