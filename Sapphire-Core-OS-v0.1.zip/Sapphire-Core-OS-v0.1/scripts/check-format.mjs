import fs from "node:fs";
import path from "node:path";

function walk(dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const full = path.join(dir, entry.name);
    return entry.isDirectory() ? walk(full) : [full];
  });
}

const files = walk(".").filter(
  (file) =>
    !file.includes("node_modules") &&
    (file.endsWith(".md") || file.endsWith(".json") || file.endsWith(".mjs")),
);

const bad = [];
for (const file of files) {
  const text = fs.readFileSync(file, "utf8");
  if (!text.endsWith("\n")) bad.push(file);
}

if (bad.length) {
  console.error("Files must end with a newline:");
  bad.forEach((file) => console.error(`- ${file}`));
  process.exit(1);
}

console.log("Formatting checks passed.");
