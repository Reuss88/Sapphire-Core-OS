# Sapphire Core OS Roadmap

## v0.1 — Repository Foundation

- Canonical repository structure
- Master architecture
- Governance
- Architecture manifest
- ADR process
- Initial Supabase and TypeScript scaffolding

## v0.2 — Business Object Foundation

- Object metamodel
- Object type register
- object identity
- attributes
- ownership
- effective time
- object history
- initial DDL and TypeScript types

## v0.3 — Relationship Architecture

- Relationship metamodel
- relationship types
- cardinality
- direction
- validity
- effective time
- relationship history
- initial DDL and RPCs

## v0.4 — Lifecycle & State

- Lifecycle definitions
- state definitions
- transitions
- guards
- transition requests
- transition evidence
- conformance checks

## v0.5 — Workflow & Orchestration

- Workflow definitions
- workflow runtime
- step instances
- assignments
- exceptions
- external execution
- workflow APIs

## v0.6 — Decision, Authority & Approval

- Decision records
- authority rules
- authority grants
- delegations
- evaluations
- approval requests and decisions

## v0.7 — Policy, Risk, Control & Compliance

## v0.8 — Information, Evidence & Security

## v0.9 — Workbench, AI, Metrics & Governance

## v1.0 — Foundational Enterprise Operating System
