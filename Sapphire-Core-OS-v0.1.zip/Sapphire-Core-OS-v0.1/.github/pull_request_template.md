## Summary

## Architecture impact

- [ ] Business Objects
- [ ] Relationships
- [ ] Lifecycle & State
- [ ] Workflow & Orchestration
- [ ] Decision, Authority & Approval
- [ ] Policy, Risk, Control & Compliance
- [ ] Information, Data & Knowledge
- [ ] Documents, Evidence & Records
- [ ] Identity, Access & Security
- [ ] Application & Human Experience
- [ ] Platform & Technical Architecture
- [ ] Intelligence Architecture
- [ ] Metrics & Governance

## Locked architecture

- [ ] This change does not silently redefine locked architecture.
- [ ] An ADR is included when required.
- [ ] Impact analysis is included.
- [ ] History, provenance, authority, and evidence are preserved.

## Testing

## Migration considerations
