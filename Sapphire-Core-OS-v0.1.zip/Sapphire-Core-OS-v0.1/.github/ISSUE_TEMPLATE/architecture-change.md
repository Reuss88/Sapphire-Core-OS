---
name: Architecture change
about: Propose a change to Sapphire Core OS architecture
title: "[Architecture] "
labels: architecture
assignees: ""
---

## Problem

## Proposed change

## Affected modules

## Locked architecture impact

## Runtime impact

## Data migration impact

## Security and authority impact

## Evidence
