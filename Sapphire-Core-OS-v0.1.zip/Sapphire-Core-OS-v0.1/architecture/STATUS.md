# Architecture Status

| Architecture area | Status |
|---|---|
| Enterprise Constitution | Principles locked; full normative consolidation pending |
| Business Object Architecture | Locked |
| Relationship Architecture | Locked |
| Lifecycle & State Architecture | Locked |
| Workflow & Orchestration Architecture | Locked |
| Decision, Authority & Approval | In design |
| Policy, Risk, Control & Compliance | Planned |
| Information, Data & Knowledge | Planned |
| Documents, Evidence & Records | Planned |
| Identity, Access & Security | Planned |
| Application & Human Experience | Planned |
| Platform & Technical Architecture | Planned |
| Intelligence Architecture | Planned |
| Metrics & Enterprise Governance | Planned |
| Horizontal Conformance Review | Planned |
| SCA v1.0 Ratification | Planned |
