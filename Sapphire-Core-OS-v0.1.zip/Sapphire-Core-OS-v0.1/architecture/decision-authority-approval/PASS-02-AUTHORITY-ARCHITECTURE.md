# Pass 2 — Authority Architecture

## Core principle

Responsibility performs work.

Authority legitimises decisions.

Access enables interaction.

Workflow coordinates execution.

These concepts are independent.

## Authority

Authority is the legitimate organisational permission to make a specified class of Decisions within defined limits.

Every authority model must answer:

1. Who?
2. May do what?
3. Under which conditions?
4. Within which limits?
5. During which effective period?
6. In which jurisdiction?

## Canonical chain

```text
Organisation
→ Governance
→ Policy
→ Authority Rule
→ Authority Grant
→ Authority Evaluation
→ Decision
→ Business Consequence
```

## Rules

- Software records and evaluates authority; software does not originate it.
- Access never creates authority.
- Responsibility never creates authority.
- Workflow routing never creates authority.
- Authority always has scope, limits, conditions, and an effective period.
- Delegation extends a grant; it does not alter the governing rule.
- Escalation transfers a Decision to sufficient authority; it does not enlarge the original actor's authority.
- AI never originates organisational authority.
