# Pass 1 — Decision Foundations

## Core principle

Decision changes organisational intent.

Workflow coordinates.

Authority permits.

Approval authorises.

Action executes.

## Decision

A Decision is a governed determination that selects one permitted organisational course of action from one or more alternatives.

## Decision hierarchy

```text
Observation
→ Measurement
→ Finding
→ Assessment
→ Recommendation
→ Decision
→ Action
```

## Key distinctions

- Recommendation is not Decision.
- Approval is a specialised Decision.
- Confirmation is evidence, not permission.
- Validation is verification, not authority.
- Assessment supports Decision.
- Workflow coordinates Decisions.
- Lifecycle applies Decisions.
- AI may recommend.
- The Decision Maker remains explicit.
- Decision history is immutable.
