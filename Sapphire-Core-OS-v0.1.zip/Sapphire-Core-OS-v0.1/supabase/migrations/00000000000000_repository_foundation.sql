-- Sapphire Core OS v0.1
-- Repository foundation migration.
-- No business runtime schema is created in this milestone.

begin;

create schema if not exists sca_meta;

comment on schema sca_meta is
  'Sapphire Core Architecture metadata. Business runtime schemas are introduced in later milestones.';

create table if not exists sca_meta.repository_release (
  release_version text primary key,
  architecture_version text not null,
  status text not null,
  released_at timestamptz not null default now(),
  notes text
);

insert into sca_meta.repository_release (
  release_version,
  architecture_version,
  status,
  notes
)
values (
  '0.1.0',
  '0.91',
  'repository_foundation',
  'Initial repository, governance, architecture manifest, and implementation scaffolding.'
)
on conflict (release_version) do nothing;

commit;
