# ADR-XXXX — Decision title

## Status

Proposed | Accepted | Superseded | Rejected

## Context

## Decision

## Consequences

## Alternatives considered

## Affected architecture modules

## Affected implementation artefacts

## Evidence

## Decision makers

## Date
