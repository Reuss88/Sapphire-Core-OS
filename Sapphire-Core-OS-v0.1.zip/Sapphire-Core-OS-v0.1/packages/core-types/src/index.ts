export type ArchitectureStatus =
  | "draft"
  | "in_review"
  | "approved"
  | "effective"
  | "locked"
  | "retired"
  | "superseded";

export interface ArchitectureReference {
  id: string;
  title: string;
  version: string;
  status: ArchitectureStatus;
}

export interface EffectivePeriod {
  effectiveFrom: string;
  effectiveTo?: string;
}
